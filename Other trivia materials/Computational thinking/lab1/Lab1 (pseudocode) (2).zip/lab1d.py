# Name: <TODO: replace with your name>
# Section: <TODO: replace with your section>

# lab1d (Binary/Stein's algo)

# All statements should only be in functions.
def gcd_d(x, y):
  return 0
