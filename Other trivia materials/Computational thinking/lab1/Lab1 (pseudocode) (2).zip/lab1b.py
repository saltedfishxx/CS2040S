# Name: <TODO: replace with your name>
# Section: <TODO: replace with your section>

# lab1b (Dijkstra's algo)

# All statements should only be in functions.
def gcd_b(x, y):
  return 0
