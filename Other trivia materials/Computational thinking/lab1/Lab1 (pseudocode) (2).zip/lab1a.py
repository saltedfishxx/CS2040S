# Name: <TODO: replace with your name>
# Section: <TODO: replace with your section>

# lab1a (Brute force)

# All statements should only be in functions.
def gcd_a(x, y):
  return 0
