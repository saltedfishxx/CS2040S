# Name: <TODO: replace with your name>
# Section: <TODO: replace with your section>

# lab1c (Euclid's algo)

# All statements should only be in functions.
def gcd_c(x, y):
  return 0
