# Name: <TODO: replace with your name>
# Section: <TODO: replace with your section>

# lab0a

# All statements should only be in functions. Do not include statements outside functions in this file.
# fill up the admit method to return either True or False depending on the sex and age
def admit(sex,age):
  return False
