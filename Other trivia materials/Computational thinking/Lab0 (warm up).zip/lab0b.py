# Name: <TODO: replace with your name>
# Section: <TODO: replace with your section>

# lab0b

# All statements should only be in functions. Do not include statements outside functions in this file.
# fill up the weight_category method to return either "underweight", "overweight" or "normal" 
# depending on the height (in cm) and weight (in kg)
def weight_category(weight, height):
  return "dummy_value"
