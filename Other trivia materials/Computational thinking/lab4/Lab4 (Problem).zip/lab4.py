# Name: <TODO: replace with your name>
# Section: <TODO: replace with your section>

# lab4

# All statements should only be in functions. Do not include statements outside functions in this file.


def select_tweeters(followers):
  # currently, this function always returns the first five users
  # obviously this arbitrary selection will result in a lousy quality score even though it's a "correct" answer :-/
  return [0, 1, 2, 3, 4]
